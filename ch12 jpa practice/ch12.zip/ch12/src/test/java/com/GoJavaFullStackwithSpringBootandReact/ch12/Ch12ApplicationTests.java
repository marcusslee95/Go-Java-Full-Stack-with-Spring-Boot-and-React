package com.GoJavaFullStackwithSpringBootandReact.ch12;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ch12ApplicationTests {

	@Test
	void contextLoads() {
	}

}
